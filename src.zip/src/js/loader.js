function hideDiv(){
    let preLoaded = document.getElementById('preloaded');
    preLoaded.style.display = 'none';
}